previous: {
    "route": {
        "key": "Welcome-LnVdXV1MpainyUR9lyp96",
        "name": "Welcome"
    },
    "descriptor": {
        "navigation": {},
        "options": {
            "gestureEnabled": true,
            "animationEnabled": true,
            "headerShown": false
        }
    },
    "progress": {
        "current": 1,
        "next": 0
    },
    "__memo": [{
        "key": "Welcome-LnVdXV1MpainyUR9lyp96",
        "name": "Welcome"
    }, {
        "height": 812,
        "width": 375
    }, {
        "navigation": {},
        "options": {
            "gestureEnabled": true,
            "animationEnabled": true,
            "headerShown": false
        }
    }, {
        "navigation": {},
        "options": {
            "gestureEnabled": true,
            "animationEnabled": true
        }
    }, null, 0, 812, null]
}
